window.recentlyViewed = {} ;
recentlyViewed.selectors = {
  template: '#RecentlyViewedProduct',
  outputContainer: '#recentView-template-grid'
};
recentlyViewed.promises = [];
recentlyViewed.current_product = $('.recentView-template').attr('current_product')
recentlyViewed.recent = JSON.parse(localStorage.getItem("recentlyViewed"));
recentlyViewed.init = function(handle) {

  for (handle in recentlyViewed.recent) {
    if (handle !== 'undefined') {
      recentlyViewed.promises.push(this.getProductInfo(recentlyViewed.recent[handle]));
    }
  }

  Promise.all(recentlyViewed.promises).then(function(result) {
    recentlyViewed.setupOutput(result);
  }.bind(this), function(error) {
    console.warn('Theme | recently viewed products failed to load');
  });

  recentlyViewed.Productrecent() ;

},
  recentlyViewed.getProductInfo = function(handle){
  return new Promise(function(resolve, reject) {
    jQuery.getJSON('/products/'+ handle +'.js', function(product) {
      resolve(product);
    });
  });
},
  recentlyViewed.setupOutput = function(products) {
  var allProducts = [];
  var data = {};
  var limit = 4;

  var i = 0;
  for (key in products) {
    var product = products[key];
    // Ignore current product
    if (product.handle === recentlyViewed.current_product ) {
      continue;
    }
    i++;
    // New or formatted properties
    product.url_formatted = recentlyViewed.recent[product.handle] ? recentlyViewed.recent[product.handle].url : product.url;
    product.image_responsive_url = product.featured_image;
    product.image_aspect_ratio = product.featured_image.aspectRatio;
    product.on_sale = product.compare_at_price > product.price;
    product.sold_out = !product.available;
    product.price_formatted = Shopify.formatMoney(product.price);
    product.compare_at_price_formatted = Shopify.formatMoney(product.compare_at_price);
    product.price_min_formatted = Shopify.formatMoney(product.price_min);
    product.money_saved = Shopify.formatMoney((product.compare_at_price - product.price));
    product.id  = product.id;
    product.handle = product.handle;
    product.variant_id = product.variants[0].id
    if (product.images.length  > 1)
    {
      product.secondery_image_avaliable = true ;
      product.secondery_image = product.images[1]
    }
    else
    {
      product.secondery_image = false ;
    }
    allProducts.unshift(product);
  }

  data = {
    items: allProducts.slice(0, limit),
    grid_item_width: 'small--one-half medium-up--one-third'
  };

  if (allProducts.length === 0) {
    return;
  }

  // Prep handlebars template
  var source = $(recentlyViewed.selectors.template).html();
  var template = Handlebars.compile(source);
  $(recentlyViewed.selectors.outputContainer).append(template(data));
  $('.recentView-template').show()

},
recentlyViewed.Productrecent = function(){
  if( JSON.parse(localStorage.getItem("recentlyViewed")) != null ) {
    var products = JSON.parse(localStorage.getItem("recentlyViewed"));
  }
  else {
    var products = [] ;
  }
  products.unshift(recentlyViewed.current_product);
  products = products.filter(recentlyViewed.onlyUnique);
  localStorage.setItem("recentlyViewed", JSON.stringify(products));
},
recentlyViewed.onlyUnique = function(value, index, self) {
  return self.indexOf(value) === index;
}