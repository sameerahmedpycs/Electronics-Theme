var Shopify = Shopify || {};
// ---------------------------------------------------------------------------
// Money format handler
// ---------------------------------------------------------------------------
Shopify.money_format = "${{amount}}";
Shopify.formatMoney = function(cents, format) {
  if (typeof cents == 'string') { cents = cents.replace('.',''); }
  var value = '';
  var placeholderRegex = /\{\{\s*(\w+)\s*\}\}/;
  var formatString = (format || this.money_format);

  function defaultOption(opt, def) {
    return (typeof opt == 'undefined' ? def : opt);
  }

  function formatWithDelimiters(number, precision, thousands, decimal) {
    precision = defaultOption(precision, 2);
    thousands = defaultOption(thousands, ',');
    decimal   = defaultOption(decimal, '.');

    if (isNaN(number) || number == null) { return 0; }

    number = (number/100.0).toFixed(precision);

    var parts   = number.split('.'),
        dollars = parts[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1' + thousands),
        cents   = parts[1] ? (decimal + parts[1]) : '';

    return dollars + cents;
  }

  switch(formatString.match(placeholderRegex)[1]) {
    case 'amount':
      value = formatWithDelimiters(cents, 2);
      break;
    case 'amount_no_decimals':
      value = formatWithDelimiters(cents, 0);
      break;
    case 'amount_with_comma_separator':
      value = formatWithDelimiters(cents, 2, '.', ',');
      break;
    case 'amount_no_decimals_with_comma_separator':
      value = formatWithDelimiters(cents, 0, '.', ',');
      break;
  }

  return formatString.replace(placeholderRegex, value);
};

const cartItem =
      `<div class="columns is-multiline is-mobile cart-drawer__products item-%PRODUCT_ID% shopItem">
      <div class="column is-4-desktop is-4-tablet is-3-mobile productImage">
          <a href="/products/%HANDLE%" aria-label="Product link"><img src="%PRODUCT_IMAGE%" alt="product" /></a>
      </div>
      <div class="column is-8-desktop is-8-tablet is-8-mobile">
          <a href="/products/%HANDLE%" aria-label="Product Title" tabindex="0"
              class="margin-b-10 margin-b-10 product-title" tabindex="0">%PRODUCT_TITLE%</a>
          <p class="select__variant">%SELECTED_VARIANT%</p>
          <p class="product-price %PRODUCT_STATE%"><span class="price-item price-item--sale">%FINAL_PRICE%</span> <span
                  class="price-item price-item--regular">%COMPARE_PRICE%</span></p>
          <div class="form-field form-options js-required">
          <div class="product-form__input product-form__quantity">
            <quantity-input class="quantity">
              <button class="quantity__button no-js-hidden" name="minus" type="button">
                <span class="visually-hidden">{{ 'products.product.quantity.decrease' | t: product: product.title | escape }}</span>
                <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" role="presentation" class="icon icon-minus" fill="none" viewBox="0 0 10 2">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M.5 1C.5.7.7.5 1 .5h8a.5.5 0 110 1H1A.5.5 0 01.5 1z" fill="currentColor">
                </svg>
              </button>
              <input class="quantity__input"
                    type="number"
                    name="quantity"
                    id="QTY-%PRODUCT_ID%"
                    min="1"
                    value="%ITEM-QUANTITY%"
                    form="product-form-%PRODUCT_ID%"
					onChange="testQty(%PRODUCT_ID%, this.value);"
                    >
              <button class="quantity__button no-js-hidden" name="plus" type="button">
                <span class="visually-hidden">{{ 'products.product.quantity.increase' | t: product: product.title | escape }}</span>
                  <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" role="presentation" class="icon icon-plus" fill="none" viewBox="0 0 10 10">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M1 4.51a.5.5 0 000 1h3.5l.01 3.5a.5.5 0 001-.01V5.5l3.5-.01a.5.5 0 00-.01-1H5.5L5.49.99a.5.5 0 00-1 .01v3.5l-3.5.01H1z" fill="currentColor">
                  </svg>
              </button>
            </quantity-input>
          </div>
          </div>
          <a onClick="removeItem(%PRODUCT_ID%);" class="is-marginless removeItem">Remove</a>
      </div>
  </div>`;
var isOpen = false;

var addedSuggested = 0;
var timer;

$( "body" ).delegate( ".add-to-cart-btn , .product-form__submit", "click", function() {
  event.preventDefault();
  var product_id = $(this).attr('product_id')
  var metaf = $(this).attr('metaf')
  addProductToCart(product_id, metaf , product_id, this )
  $('#quick-view .quick-view_grid').remove();
  $('#quick-view').hide() ;
});

function addProductToCart(formID, metafields, productID, target) {

  window.localStorage.setItem("timer", new Date().getTime() + 10 * 60 * 1000);

  if (isNotLoading()) {
    startLoading();
  }
  if (!isCartOpen()) {
    openCart();
  }

  $.ajax({
    type: 'POST',
    url: '/cart/add.js',
    dataType: 'json',
    data: $(target).closest('.'+formID).serialize(),
    success: addToCartOk,
    error: addToCartFail,
  });
  if (metafields != "") {
    window.localStorage.setItem('metafields-' + productID, metafields);
  }
  return false;
}

function testQty(itemID, value) {
  if (value != "Dummy") {
    changeItem(itemID, value);
  }
}

function fetchCart() {
  $.ajax({
    type: 'GET',
    url: '/cart.js',
    dataType: 'json',
    success: function (cart) {
      onCartUpdate(cart);
      renderCart(cart);
    },
  });
}

function changeItem(line, quantity, callback) {
  if (isNotLoading()) {
    startLoading();
  }
  $.ajax({
    type: 'POST',
    url: '/cart/change.js',
    data: 'quantity=' + quantity + '&id=' + line,
    dataType: 'json',
    success: function (cart) {
      if ((typeof callback) === 'function') {
        callback(cart);
      } else {
        onCartUpdate(cart);
        fetchCart();
      }
    },
    error: addToCartFail,
  });
}

function replaceAll(str, find, replace) {
  return str.replace(new RegExp(find, 'g'), replace);
}

function removeItem(itemID) {
  changeItem(itemID, 0);
  $("item-" + itemID).remove();
}

function onCartUpdate(cart) {
  // Do nothing, logic handled before render
}

function addToCartOk(product) {
  setTimeout(() => fetchCart(), 500);
}

function addToCartFail() {
  console.log("Error adding to cart: ");
}

function renderCart(cart) {
  const cartItemHolder = $(".cart-drawer__cart");

  // console.log("Cart: " + JSON.stringify(cart));

  if (cart.items.length != 0) {
    $(".cartEmptyHolder").addClass("is-hidden");
    $(".cartItemHolder").removeClass("is-hidden");
  } else {
    $(".cartEmptyHolder").removeClass("is-hidden");
    $(".cartItemHolder").addClass("is-hidden");
  }

  $("#product1Variant").change(function () {
    // console.log("CLICK: " + this.value);
    $("#product1_price").text(product1_price[this.value]);
    $("#product1_compare").text(product1_compare[this.value]);
  });

  var cartCount = $(".site-header-cart--count");

  $(".header-cart-count").text(cart.item_count);

  $(".shopItem").remove();

  var cartTotal = 0;

  $("#product1Form").css("display", "block");
  $("#product2Form").css("display", "block");
  $(".cart-drawer_similar-header").css("display", "block");
  addedSuggested = 0;

  // console.log(cart)
  cart.items.forEach(function (item, index) {

    cartTotal += item.quantity;

    var subtotal = "" + Shopify.formatMoney(cart.items_subtotal_price);
    var cost = "" + Shopify.formatMoney(item.price);
    var cost2 = '$' + cost;
    var cartItem2 = replaceAll(cartItem, "%PRODUCT_TITLE%", item.product_title);
    if(item.image != null){
        cartItem2 = replaceAll(cartItem2, "%PRODUCT_IMAGE%", (item.image).replace(".png", "_170x170.png").replace(".jpg", "_170x170.jpg"));
    }
    else {
      cartItem2 = replaceAll(cartItem2, "%PRODUCT_IMAGE%", "");

    }
    cartItem2 = replaceAll(cartItem2, "%PRODUCT_STATE%", "price--on-regular");
    cartItem2 = replaceAll(cartItem2, "%FINAL_PRICE%", "");
    cartItem2 = replaceAll(cartItem2, "%COMPARE_PRICE%", cost2);
    cartItem2 = replaceAll(cartItem2, "%ITEM-QUANTITY%", item.quantity);    
    
    if (item.variant_options[0] != "Default Title"){
      cartItem2 = replaceAll(cartItem2, "%SELECTED_VARIANT%", item.variant_title);
    }else{
      cartItem2 = replaceAll(cartItem2, "%SELECTED_VARIANT%", " ");
    }
    cartItem2 = replaceAll(cartItem2, "%PRODUCT_ID%", item.id);
    cartItem2 = replaceAll(cartItem2, "%HANDLE%", item.handle);
    cartItemHolder.prepend(cartItem2);
    $('.cart-drawer').find('.productImage img[src=""]').parents('.productImage').addClass('placeholder-product-image')
    $('.cart-drawer').find('.productImage img[src=""]').remove();

    $(".items_subtotal").text(subtotal);
    $('#QTY-' + item.id + ' option:nth-child(' + (item.quantity + 1) + ')').attr("selected", true);

  });
  if (cart.item_count > 1) {
    itemTimer(cart);
  } else if (cart.item_count == 1) {
    itemTimer(cart);
  } else {
    $(".cart-drawer__timer").addClass("is-hidden");
    $(".items_subtotal").text("Empty");
    itemTimer(cart) 
  }

  if (cartCount.attr("data-header-cart-count") != (cartTotal)) {
    cartCount.attr("data-header-cart-count", (cartTotal));
  }

  stopLoading();

}

function onTidioChatApiReady() {
  setTimeout(() => $("#tidio-chat-iframe").css("z-index", "699"), 500);
}

document.addEventListener('DOMContentLoaded', function () {

  // Set the cart height to 100 "true" vh, fixes ios issues with vh.
  // $(".cart-flyout").css("height", $(window).height());


  if (window.tidioChatApi) {
    window.tidioChatApi.on("ready", onTidioChatApiReady);
  } else {
    document.addEventListener("tidioChat-ready", onTidioChatApiReady);
  }
  fetchCart();
});

function closeCart() {
  $('html').css("overflow-y", "scroll");
  isOpen = false;
  $(".cart-flyout").addClass("is-closing");
  $(".cart-flyout").removeClass("is-active");
  $(".cart-flyout").hide()
  $(".cartOverlay").css("opacity", "0");
  setTimeout(() =>  $(".cart-flyout").removeClass("is-closing"), 750);
}

function openCart() {
  $('html').css("overflow-y", "hidden");
  isOpen = true;
  $(".cart-flyout").show()
  $(".cart-flyout").removeClass("is-closing");
  $(".cart-flyout").addClass("is-active");

  setTimeout(() => $(".cartOverlay").css("opacity", "1"), 400);
}




document.getElementById("cart-icon-bubble").addEventListener("click", function(event){
  event.preventDefault()
  toggleCart() 
});

function toggleCart() {
  event.preventDefault() ;
  if (isCartOpen()) {
    closeCart();
    return false;
  } else {
    openCart();
    return false;
  }
}

function isCartOpen() {
  return isOpen;
}

function clickOverlay() {
  toggleCart();
}

function addSuggested(formID, metafields, itemID, productID) {

  window.localStorage.setItem("timer", new Date().getTime() + 10 * 60 * 1000);
  if (isNotLoading()) {
    startLoading();
  }
  if (!isCartOpen()) {
    openCart();
  }
  if ($("#" + productID + "Variant").val() != null) {
    itemID = $("#" + productID + "Variant").val();
  }
  $("#" + productID + "Qty").attr("value", $("#" + productID + "Select").val());
  $("#" + productID + "Input").attr("value", itemID);
  addProductToCart(formID, metafields, itemID);
  $("#" + productID + "Form").css("display", "none");
}

function startLoading() {
  $(".cartLoader").removeClass("is-hidden");
}

function stopLoading() {
  $(".cartLoader").addClass("is-hidden");
}

function isNotLoading() {
  return $(".cartLoader").hasClass("is-hidden");
}

function itemTimer(cart) {
  var isSingle = true;
  if(cart.item_count > 1) isSingle = false; 
  var second = 1000,
      minute = second * 60,
      hour = minute * 60,
      day = hour * 24;
  if(timer || cart.item_count === 0) {
    clearInterval(timer)
  }
  var countDown = Number(window.localStorage.getItem('timer'));
  if(cart.item_count > 0) {
    timer = setInterval(function() {
      var now = new Date().getTime(),
          distance = countDown - now;
      // console.log("Set item count");
      $(".itemCount").removeClass('is-hidden');
      $(".itemCount").text(':' + ' ' + cart.item_count + ` Item${!isSingle ? 's' : ''}`);
      if(distance > 0) {
        $(".cart-drawer__timer").removeClass('is-hidden');
        let _minutes = Math.floor((distance % (hour)) / (minute));
        let _seconds = Math.floor((distance % (minute)) / second);
        $(".itemTimer").text(`Item${!isSingle ? 's' : ''} in your cart ${!isSingle ? 'are' : 'is'} in high demand! Your cart is reserved for ${_minutes < 10 ? '0' + _minutes : _minutes}:${_seconds < 10 ? '0' + _seconds : _seconds} minutes.`);
      }else {
        $(".itemCount").text(':' + ' ' + cart.item_count + ` Item${!isSingle ? 's' : ''}`);
        $(".cart-drawer__timer").addClass('is-hidden');
      }
    }, second)
  } else {
    $(".itemCount").addClass('is-hidden');


  }
}


$( document ).ready(function() {

  $('.product-gallery--thumbnails').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    fade: true,
  });

  $('.product-gallery--navigation').slick({
    slidesToShow: 4 ,
    slidesToScroll: 1,
    vertical: true,
    verticalSwiping: true,
    dots: false,
    infinite: false,
    centerMode: false,
    arrows: false,
    responsive: [
      {
        breakpoint: 769,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 3,
          vertical: false,
          verticalSwiping: false,
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          vertical: false,
          verticalSwiping: false,

        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          vertical: false,
          verticalSwiping: false,
        }
      }
    ]
  });


  $('.product-gallery--navigation-inner').click(function(){

    $('.product-gallery--navigation-inner').removeClass('current') ;
    $(this).addClass('current')
    var to_slide =  $(this).attr('data-slick-index');
    $('.product-gallery--thumbnails').slick('slickGoTo', to_slide);
    $('.product-gallery--navigation').slick('slickGoTo', to_slide);
  });


  $('.product_single-navigation').on('init', function(event, slick){
    setTimeout(() => {
      $('.product_single-media').css('opacity', '1');
    },1500);
  });

  $('.product_single-thumbnails').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    fade: true
  });
    
  $('.product_single-navigation').slick({
    slidesToShow: 4 ,
    slidesToScroll: 1,
    vertical: true,
    verticalSwiping: true,
    dots: false,
    infinite: false,
    centerMode: false,
    arrows: false,
    responsive: [
      {
        breakpoint: 769,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 3,
          vertical: false,
          verticalSwiping: false,
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          vertical: false,
          verticalSwiping: false,

        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          vertical: false,
          verticalSwiping: false,
        }
      }
    ]
  });

  $('.product-single-gallery--navigation-inner').click(function(){
    $('.product-single-gallery--navigation-inner').removeClass('current') ;
    $(this).addClass('current')
    var to_slide =  $(this).attr('data-slick-index');
    $('.product_single-thumbnails').slick('slickGoTo', to_slide);
    $('.product_single-navigation').slick('slickGoTo', to_slide);
  });

  $('[data_options="color"] input[type="radio"]').change(function(){
    $(this).parents('.product-form__input').find('.form__label span').text($(this).val());
  });

  $('.dropdown_menu .header_link_item').click(function(event){
    event.preventDefault();
    $('.dropdown_menu .header_link_item').not($(this)).parents('.dropdown_menu').removeClass('open');
    $(this).parents('.dropdown_menu').toggleClass('open') ;
  });

  $(document).mouseup(function(e)  {
    var container = $(".dropdown_menu");
    if (!container.is(e.target) && container.has(e.target).length === 0) {
      $('.dropdown_menu').removeClass('open')
    }
    
    var container2 = $(".header-category label");
    if (!container2.is(e.target) && container2.has(e.target).length === 0) {
      $('.header-category ').removeClass('open')
    }
    
    var container3 = $(".account_detail");
    if (!container3.is(e.target) && container3.has(e.target).length === 0) {
      $('.search-all-Category--account').removeClass('open')
    }
  });
  
  $('.header-category label').click(function(){
    $(this).parents('.header-category').toggleClass('open')
  });
  
  $('.account_detail').click(function(){
    $(this).parents('.search-all-Category--account').toggleClass('open')
  });

  $('.product_single-thumbnails').on('beforeChange', function(event, slick, currentSlide, nextSlide){
    $('.product-single-gallery--navigation-inner').removeClass('current') ;
    $(`.product-single-gallery--navigation-inner[data-slick-index="${nextSlide}"]`).addClass('current')
  });

  $('.cart-drawer__proceed-to-checkout').click(function(e){
    e.preventDefault()
    $.ajax({
      type: 'POST',
      url: '/cart',
      data: $(this).parents('form[action="/cart"]').serialize(),
      dataType: 'json',
      success: function (cart) {
        window.location.href = '/checkout'
      },
      error: addToCartFail,
    });
  });

});


class VariantProductcardSelects extends HTMLElement {
  constructor() {
    super();
    this.addEventListener('change', this.onVariantProductcardChange);
  }
  onVariantProductcardChange() {
    this.updateOptions();
    this.updateMasterId();
    this.updateMediaPrice()
    this.closest('.card-wrapper').querySelector('input[name="id"]').setAttribute('value', this.currentVariant.id)
  }

  updateOptions() {
    this.options = Array.from(this.querySelectorAll('select'), (select) => select.value);
  }
  updateMasterId() {
    this.currentVariant = this.getVariantData().find((variant) => {
      return !variant.options.map((option, index) => {
        return this.options[index] === option;
      }).includes(false);
    });
  }
  getVariantData() {
    this.variantData = this.variantData || JSON.parse(this.querySelector('[type="application/json"]').textContent);
    return this.variantData;
  }
  updateMediaPrice(){
    console.log(this.currentVariant)
    this.closest('.card-wrapper').querySelector('.price__regular .price-item--regular').innerHTML =  `From ${Shopify.formatMoney(this.currentVariant.price)}`
    if (this.currentVariant.featured_image != null){
      this.closest('.card-wrapper').querySelector('.primery_card_image').setAttribute('src', this.currentVariant.featured_image.src)
    }
  }
}
class VariantProductcard extends VariantProductcardSelects {
  constructor() {
    super();
  }
  updateOptions() {
    const fieldsets = Array.from(this.querySelectorAll('fieldset'));
    this.options = fieldsets.map((fieldset) => {
      return Array.from(fieldset.querySelectorAll('input')).find((radio) => radio.checked).value;
    });
  }
}

customElements.define('variant-productcard', VariantProductcard);


let accordionBtn = document.querySelectorAll('.accordion-btn');
for (let i = 0; i < accordionBtn.length; i++) {
  accordionBtn[i].addEventListener('click', function(){
    this.classList.toggle('isOpen');
    let accordionContent = this.nextElementSibling;
    if (accordionContent.style.maxHeight) {
	accordionContent.style.maxHeight = null;
    } else {
      accordionContent.style.maxHeight = accordionContent.scrollHeight + 'px';
    }
  });
}


//product page tabs
const labels = document.querySelectorAll(".accordion-item__label");
const tabs = document.querySelectorAll(".accordion-tab");

function toggleShow() {
	const target = this;
	const item = target.classList.contains("accordion-tab")
		? target
		: target.parentElement;
	const group = item.dataset.actabGroup;
	const id = item.dataset.actabId;

	tabs.forEach(function(tab) {
		if (tab.dataset.actabGroup === group) {
			if (tab.dataset.actabId === id) {
				tab.classList.add("accordion-active");
			} else {
				tab.classList.remove("accordion-active");
			}
		}
	});

	labels.forEach(function(label) {
		const tabItem = label.parentElement;

		if (tabItem.dataset.actabGroup === group) {
			if (tabItem.dataset.actabId === id) {
				tabItem.classList.add("accordion-active");
			} else {
				tabItem.classList.remove("accordion-active");
			}
		}
	});
}

labels.forEach(function(label) {
	label.addEventListener("click", toggleShow);
});

tabs.forEach(function(tab) {
	tab.addEventListener("click", toggleShow);
});
