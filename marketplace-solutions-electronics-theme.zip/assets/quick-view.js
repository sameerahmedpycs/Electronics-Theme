class VariantSelectsQuickview extends HTMLElement {
  constructor() {
    super();
    this.addEventListener('change', this.onQuickViewVariantChange);
  }
  onQuickViewVariantChange() {
    this.updateOptions();
    this.updateMasterId();
    this.updateMediaPrice()
    $('.quick-view_grid').find('input[name="id"]').val(this.currentVariant.id)
  }

  updateOptions() {
    this.options = Array.from(this.querySelectorAll('select'), (select) => select.value);
  }
  updateMasterId() {
    this.currentVariant = this.getVariantData().find((variant) => {
      return !variant.options.map((option, index) => {
        return this.options[index] === option;
      }).includes(false);
    });
  }
  getVariantData() {
    this.variantData = this.variantData || JSON.parse(this.querySelector('[type="application/json"]').textContent);
    return this.variantData;
  }
  updateMediaPrice(){
    $('.quick-view_price h1').html(Shopify.formatMoney(this.currentVariant.price))
    if (this.currentVariant.featured_image != null){
      var slide = $('.quick-view_image[media-id="'+this.currentVariant.featured_image.id+'"]').attr('data-slick-index')
      $('.quick-view_slider').slick('slickGoTo', slide);
    }
  }
}
class VariantQuickview extends VariantSelectsQuickview {
  constructor() {
    super();
  }
  updateOptions() {
    const fieldsets = Array.from(this.querySelectorAll('fieldset'));
    this.options = fieldsets.map((fieldset) => {
      return Array.from(fieldset.querySelectorAll('input')).find((radio) => radio.checked).value;
    });
  }
}
customElements.define('variant-quickview', VariantQuickview);


$( document ).ready(function() {
  function addProductToCart(formID, metafields, productID, target) {
    window.localStorage.setItem("timer", new Date().getTime() + 10 * 60 * 1000);
    if (isNotLoading()) {
      startLoading();
    }
    if (!isCartOpen()) {
      openCart();
    }
    $.ajax({
      type: 'POST',
      url: '/cart/add.js',
      dataType: 'json',
      data:  {
        quantity: $(target).closest('.'+formID).find('input[name="quantity"]').val(),
        id: $(target).closest('.'+formID).find('input[name="id"]').val()
      },
      success: addToCartOk,
      error: addToCartFail,
    });
    if (metafields != "") {
      window.localStorage.setItem('metafields-' + productID, metafields);
    }
    return false;
  }
  function ajax(options) {
    return new Promise(function (resolve, reject) {
      $.ajax(options).done(resolve).fail(reject);
    });
  }

  $('.quick-view_slider').on('init', function(event, slick){
  });

  
$( "body" ).delegate( 'fieldset[data_options="color"] input[type="radio"]', "change", function() {
   $(this).parents('fieldset[data_options="color"] ').find('.form__label span').html($(this).val())
});

  $( "body" ).delegate( ".quick_view_btn.enabled", "click", function() {
    var $self = $(this)
    $self.removeClass('enabled')

    let product = $(this).data('product')

    ajax({
      type: 'GET',
      url: `/products/${product}?view=quick-view`,
      dataType: "html"
    }).then(
      function fulfillHandler(data) {
        var filteredData = $(data).find(".quick-view_grid");
        $('#quick-view .modal-content').append(filteredData)
        $('#quick-view').show() ;   
        $('.quick-view_slider').slick({ dots: false,infinite: false,speed: 300, slidesToShow: 1,adaptiveHeight: true,arrows: true,prevArrow: $('.quick_slick_prev'), nextArrow: $('.quick_slick_next')});
           $self.addClass('enabled');
         $(window).on("load resize",function(e){
        });
      },
      function rejectHandler(jqXHR, textStatus, errorThrown) {

      }
    ).catch(function errorHandler(error) {

    });
   
  });
  $('.modal-content .close').click(function(){
    $('#quick-view .quick-view_grid').remove();
    $('#quick-view').hide() ;    
  });

  $( "body" ).delegate( "#quick-view_add", "click", function() {
    event.preventDefault();
    var product_id = $(this).attr('product_id')
    var metaf = $(this).attr('metaf')
    addProductToCart(product_id, metaf , product_id, this )
    $('#quick-view .quick-view_grid').remove();
    $('#quick-view').hide() ;
  });
  
});
