class PredictiveSearch extends HTMLElement {
    constructor() {
      super();
      this.input = this.querySelector('input[type="search"]');
      this.predictiveSearchResults = this.querySelector('.predictive_search_results');
      this.input.addEventListener('input', debounce((event) => {
        this.onChange(event);
  
      }, 300).bind(this));
    }
    onChange() {
      const searchTerm = this.input.value.trim();
      if (!searchTerm.length) {
        this.close();
        return;
      }
      this.getSearchResults(searchTerm);
    }
  
    getSearchResults(searchTerm) {
      fetch(`/search?q=${searchTerm}&resources[type]=product&resources[limit]=6&view=search-json`)
      .then((response) => {
        if (!response.ok) {
          var error = new Error(response.status);
          this.close();
          throw error;
        }
        return response.json();
      }).then((json) => {
        var products = json.resources.results.products ;
        this.buindCards(products)
        if (products.length === 0) {
          this.close();
        }
        else
        {
          this.open();
        }
  
      }).catch((error) => {
        this.close();
        throw error;
      });
  
    }
  
    buindCards(products) {
      $(this).find('.predictive_search_results .search_results_items').empty() ;
      products.forEach((product, indx) => {
        let search_card =  `
  <div class="search_result_card">
  <a href="${product.url}">
  <div class="search_result_card_inner">
  <div class="search_result_card_image">
  <img src="${product.image}">
  </div>
  <div class="search_result_card_info">
  <h4>${product.title}</h4>
  <span class="">${Shopify.formatMoney(product.price_min)}</span>
  </div>
  </div>
  </a>
  </div>
  `
        $(this).find('.predictive_search_results .search_results_items').append(search_card) 
      });
    }
  
    open() {
      this.predictiveSearchResults.style.display = 'block';
    }
    close() {
      this.predictiveSearchResults.style.display = 'none';
    }
  }
  customElements.define('predictive-search', PredictiveSearch);
  $( document ).ready(function() {
    $('.search-modal__close-button ').click(function(){
      $(this).find('.predictive_search_results .search_results_items').empty() ;
      $('.predictive_search_results').hide()
    });
  });