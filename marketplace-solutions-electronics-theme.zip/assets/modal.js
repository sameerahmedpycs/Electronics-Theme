
var toggleEmailPopUp = () =>{
    var ele = document.getElementById("modal-container");

    if (ele.classList.contains("six")){
        ele.classList.add("out");
        setTimeout(() =>{
            ele.classList.remove("six");
        },1000)
    }else{
        ele.classList.remove("out");
        ele.classList.add("six");
    }
}

var fixEmailPopUp = (e) =>{
    e.stopPropagation();
}