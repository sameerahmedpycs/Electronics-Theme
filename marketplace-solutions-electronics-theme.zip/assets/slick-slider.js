$( document ).ready(function() {
    $('.collection-slider-product').on('init', function(event, slick) {
      
        $('.collection-slider-product.slick-initialized').css({'opacity': '1', 'visibility': 'visible'});
      });
      $('.hero-section').on('init', function(event, slick) {
        $('.hero-section.slick-initialized').css({'opacity': '1', 'visibility': 'visible'});
      });
      $('.hero-section').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        infinite: true,
        dots: true,
        arrows: true
      });
      $('.collection-slider-product').slick({
        slidesToShow: 4,
        slidesToScroll: 4,
        infinite: false,
        dots: false,
        arrows: true,
        speed: 500,
        autoplay: false,
        adaptiveheight: false,
        prevArrow:'<button type="button" class="slick-prev slick-arrow"><svg class="flickity-button-icon" viewBox="0 0 100 100"><path d="M 10,50 L 60,100 L 70,90 L 30,50  L 70,10 L 60,0 Z" class="arrow"></path></svg></button>',
        nextArrow:'<button type="button" class="slick-next slick-arrow"><svg class="flickity-button-icon" viewBox="0 0 100 100"><path d="M 10,50 L 60,100 L 70,90 L 30,50  L 70,10 L 60,0 Z" class="arrow" transform="translate(100, 100) rotate(180) "></path></svg></button>',
        responsive: [
          {
            breakpoint: 1100,
            settings: {
              slidesToShow: 3,
              slidesToScroll: 3
            }
          },
          {
            breakpoint: 768,
            settings: {
              slidesToShow: 2,
              slidesToScroll: 2
            }
          },
          {
            breakpoint: 480,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1
            }
          }
    
        ]
      });
});